# pkg_for_practice

Practice package!

## Installation

```bash
$ pip install pkg_for_practice
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`pkg_for_practice` was created by Michaela Flum. It is licensed under the terms of the MIT license.

## Credits

`pkg_for_practice` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
